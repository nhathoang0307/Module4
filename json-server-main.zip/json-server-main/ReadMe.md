- [https://my-json-server.typicode.com/sunrise8vn/json-server](https://my-json-server.typicode.com/sunrise8vn/json-server)

- npm install json-server --save-dev
- node server.js
- json-server --watch db.json

